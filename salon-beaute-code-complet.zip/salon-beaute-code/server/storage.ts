import {
  users,
  services,
  clients,
  staff,
  appointments,
  waitingList,
  forumCategories,
  forumPosts,
  forumReplies,
  forumLikes,
  reviews,
  loyaltyProgram,
  promotions,
  notifications,
  type User,
  type UpsertUser,
  type Service,
  type InsertService,
  type Client,
  type InsertClient,
  type Staff,
  type InsertStaff,
  type Appointment,
  type InsertAppointment,
  type WaitingListItem,
  type InsertWaitingList,
  type ForumPost,
  type InsertForumPost,
  type ForumReply,
  type InsertForumReply,
  type ForumCategory,
  type Review,
  type InsertReview,
  type LoyaltyProgram,
  type InsertLoyaltyProgram,
  type Promotion,
  type InsertPromotion,
  type Notification,
  type InsertNotification,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql, count } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Service operations
  getServices(userId: string): Promise<Service[]>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, service: Partial<InsertService>): Promise<Service>;
  deleteService(id: number): Promise<void>;

  // Client operations
  getClients(userId: string): Promise<Client[]>;
  getClient(id: number): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, client: Partial<InsertClient>): Promise<Client>;
  deleteClient(id: number): Promise<void>;
  searchClients(userId: string, query: string): Promise<Client[]>;

  // Staff operations
  getStaff(userId: string): Promise<Staff[]>;
  getStaffMember(id: number): Promise<Staff | undefined>;
  createStaffMember(staff: InsertStaff): Promise<Staff>;
  updateStaffMember(id: number, staff: Partial<InsertStaff>): Promise<Staff>;
  deleteStaffMember(id: number): Promise<void>;

  // Appointment operations
  getAppointments(userId: string, date?: string): Promise<(Appointment & { client?: Client; service?: Service; staff?: Staff })[]>;
  getAppointment(id: number): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment>;
  deleteAppointment(id: number): Promise<void>;
  getAppointmentsByDateRange(userId: string, startDate: string, endDate: string): Promise<Appointment[]>;

  // Waiting list operations
  getWaitingList(userId: string): Promise<(WaitingListItem & { client?: Client; service?: Service })[]>;
  addToWaitingList(item: InsertWaitingList): Promise<WaitingListItem>;
  removeFromWaitingList(id: number): Promise<void>;

  // Forum operations
  getForumCategories(): Promise<ForumCategory[]>;
  getForumPosts(categoryId?: number, limit?: number): Promise<(ForumPost & { user: User })[]>;
  getForumPost(id: number): Promise<(ForumPost & { user: User; replies: (ForumReply & { user: User })[] }) | undefined>;
  createForumPost(post: InsertForumPost): Promise<ForumPost>;
  createForumReply(reply: InsertForumReply): Promise<ForumReply>;
  likeForumPost(userId: string, postId: number): Promise<void>;
  unlikeForumPost(userId: string, postId: number): Promise<void>;

  // Analytics
  getDashboardStats(userId: string): Promise<{
    todayAppointments: number;
    weekRevenue: number;
    monthRevenue: number;
    totalClients: number;
  }>;
  
  // Advanced Analytics for Dashboard
  getRevenueChart(userId: string): Promise<Array<{ date: string; revenue: number }>>;
  getUpcomingAppointments(userId: string): Promise<Array<{ date: string; time: string; clientName: string; serviceName: string }>>;
  getTopServices(userId: string): Promise<Array<{ serviceName: string; count: number; revenue: number }>>;
  getStaffPerformance(userId: string): Promise<Array<{ staffName: string; revenue: number; appointmentCount: number }>>;

  // Reviews operations
  getReviews(userId: string): Promise<(Review & { client: Client; service: Service })[]>;
  createReview(review: InsertReview): Promise<Review>;

  // Advanced Analytics operations
  getAnalyticsOverview(userId: string, timeRange: string): Promise<any>;
  getAnalyticsRevenueChart(userId: string, timeRange: string): Promise<any[]>;
  getClientSegments(userId: string, timeRange: string): Promise<any[]>;
  getServiceAnalytics(userId: string, timeRange: string): Promise<any[]>;
  getLoyaltyStats(userId: string): Promise<any>;
  getTopClients(userId: string, timeRange: string): Promise<any[]>;

  // Loyalty program operations
  getLoyaltyProgram(clientId: number): Promise<LoyaltyProgram | undefined>;
  createLoyaltyProgram(loyalty: InsertLoyaltyProgram): Promise<LoyaltyProgram>;
  updateLoyaltyPoints(clientId: number, points: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Service operations
  async getServices(userId: string): Promise<Service[]> {
    return await db
      .select()
      .from(services)
      .where(and(eq(services.userId, userId), eq(services.isActive, true)))
      .orderBy(services.name);
  }

  async createService(service: InsertService): Promise<Service> {
    const [newService] = await db.insert(services).values(service).returning();
    return newService;
  }

  async updateService(id: number, service: Partial<InsertService>): Promise<Service> {
    const [updated] = await db
      .update(services)
      .set(service)
      .where(eq(services.id, id))
      .returning();
    return updated;
  }

  async deleteService(id: number): Promise<void> {
    await db.update(services).set({ isActive: false }).where(eq(services.id, id));
  }

  // Client operations
  async getClients(userId: string): Promise<Client[]> {
    return await db
      .select()
      .from(clients)
      .where(eq(clients.userId, userId))
      .orderBy(desc(clients.lastVisit), clients.firstName);
  }

  async getClient(id: number): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client;
  }

  async createClient(client: InsertClient): Promise<Client> {
    const [newClient] = await db.insert(clients).values(client).returning();
    return newClient;
  }

  async updateClient(id: number, client: Partial<InsertClient>): Promise<Client> {
    const [updated] = await db
      .update(clients)
      .set(client)
      .where(eq(clients.id, id))
      .returning();
    return updated;
  }

  async deleteClient(id: number): Promise<void> {
    await db.delete(clients).where(eq(clients.id, id));
  }

  async searchClients(userId: string, query: string): Promise<Client[]> {
    return await db
      .select()
      .from(clients)
      .where(
        and(
          eq(clients.userId, userId),
          sql`(${clients.firstName} || ' ' || ${clients.lastName}) ILIKE ${`%${query}%`}`
        )
      )
      .orderBy(clients.firstName);
  }

  // Staff operations
  async getStaff(userId: string): Promise<Staff[]> {
    return await db
      .select()
      .from(staff)
      .where(and(eq(staff.userId, userId), eq(staff.isActive, true)))
      .orderBy(staff.firstName);
  }

  async getStaffMember(id: number): Promise<Staff | undefined> {
    const [staffMember] = await db.select().from(staff).where(eq(staff.id, id));
    return staffMember;
  }

  async createStaffMember(staffData: InsertStaff): Promise<Staff> {
    const [newStaff] = await db.insert(staff).values(staffData).returning();
    return newStaff;
  }

  async updateStaffMember(id: number, staffData: Partial<InsertStaff>): Promise<Staff> {
    const [updated] = await db
      .update(staff)
      .set(staffData)
      .where(eq(staff.id, id))
      .returning();
    return updated;
  }

  async deleteStaffMember(id: number): Promise<void> {
    await db.update(staff).set({ isActive: false }).where(eq(staff.id, id));
  }

  // Appointment operations
  async getAppointments(userId: string, date?: string): Promise<(Appointment & { client?: Client; service?: Service })[]> {
    const query = db
      .select({
        id: appointments.id,
        userId: appointments.userId,
        clientId: appointments.clientId,
        serviceId: appointments.serviceId,
        staffId: appointments.staffId,
        clientName: appointments.clientName,
        clientEmail: appointments.clientEmail,
        clientPhone: appointments.clientPhone,
        appointmentDate: appointments.appointmentDate,
        startTime: appointments.startTime,
        endTime: appointments.endTime,
        status: appointments.status,
        notes: appointments.notes,
        totalPrice: appointments.totalPrice,
        depositPaid: appointments.depositPaid,
        paymentStatus: appointments.paymentStatus,
        createdAt: appointments.createdAt,
        client: clients,
        service: services,
        staff: staff,
      })
      .from(appointments)
      .leftJoin(clients, eq(appointments.clientId, clients.id))
      .leftJoin(services, eq(appointments.serviceId, services.id))
      .leftJoin(staff, eq(appointments.staffId, staff.id))
      .where(
        date 
          ? and(eq(appointments.userId, userId), eq(appointments.appointmentDate, date))
          : eq(appointments.userId, userId)
      )
      .orderBy(appointments.appointmentDate, appointments.startTime);

    return await query;
  }

  async getAppointment(id: number): Promise<Appointment | undefined> {
    const [appointment] = await db.select().from(appointments).where(eq(appointments.id, id));
    return appointment;
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [newAppointment] = await db.insert(appointments).values(appointment).returning();
    return newAppointment;
  }

  async updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment> {
    const [updated] = await db
      .update(appointments)
      .set(appointment)
      .where(eq(appointments.id, id))
      .returning();
    return updated;
  }

  async deleteAppointment(id: number): Promise<void> {
    await db.delete(appointments).where(eq(appointments.id, id));
  }

  async getAppointmentsByDateRange(userId: string, startDate: string, endDate: string): Promise<Appointment[]> {
    return await db
      .select()
      .from(appointments)
      .where(
        and(
          eq(appointments.userId, userId),
          gte(appointments.appointmentDate, startDate),
          lte(appointments.appointmentDate, endDate)
        )
      )
      .orderBy(appointments.appointmentDate, appointments.startTime);
  }

  // Waiting list operations
  async getWaitingList(userId: string): Promise<(WaitingListItem & { client?: Client; service?: Service })[]> {
    const query = db
      .select({
        id: waitingList.id,
        userId: waitingList.userId,
        clientId: waitingList.clientId,
        serviceId: waitingList.serviceId,
        preferredDate: waitingList.preferredDate,
        isFlexible: waitingList.isFlexible,
        notified: waitingList.notified,
        createdAt: waitingList.createdAt,
        client: clients,
        service: services,
      })
      .from(waitingList)
      .leftJoin(clients, eq(waitingList.clientId, clients.id))
      .leftJoin(services, eq(waitingList.serviceId, services.id))
      .where(eq(waitingList.userId, userId))
      .orderBy(waitingList.createdAt);

    return await query;
  }

  async addToWaitingList(item: InsertWaitingList): Promise<WaitingListItem> {
    const [newItem] = await db.insert(waitingList).values(item).returning();
    return newItem;
  }

  async removeFromWaitingList(id: number): Promise<void> {
    await db.delete(waitingList).where(eq(waitingList.id, id));
  }

  // Forum operations
  async getForumCategories(): Promise<ForumCategory[]> {
    return await db
      .select()
      .from(forumCategories)
      .where(eq(forumCategories.isActive, true))
      .orderBy(forumCategories.name);
  }

  async getForumPosts(categoryId?: number, limit = 20): Promise<(ForumPost & { user: User })[]> {
    const query = db
      .select({
        id: forumPosts.id,
        categoryId: forumPosts.categoryId,
        userId: forumPosts.userId,
        title: forumPosts.title,
        content: forumPosts.content,
        isPinned: forumPosts.isPinned,
        isLocked: forumPosts.isLocked,
        viewCount: forumPosts.viewCount,
        likeCount: forumPosts.likeCount,
        replyCount: forumPosts.replyCount,
        createdAt: forumPosts.createdAt,
        updatedAt: forumPosts.updatedAt,
        user: users,
      })
      .from(forumPosts)
      .leftJoin(users, eq(forumPosts.userId, users.id))
      .where(categoryId ? eq(forumPosts.categoryId, categoryId) : undefined)
      .orderBy(desc(forumPosts.isPinned), desc(forumPosts.updatedAt))
      .limit(limit);

    return await query;
  }

  async getForumPost(id: number): Promise<(ForumPost & { user: User; replies: (ForumReply & { user: User })[] }) | undefined> {
    const [post] = await db
      .select({
        id: forumPosts.id,
        categoryId: forumPosts.categoryId,
        userId: forumPosts.userId,
        title: forumPosts.title,
        content: forumPosts.content,
        isPinned: forumPosts.isPinned,
        isLocked: forumPosts.isLocked,
        viewCount: forumPosts.viewCount,
        likeCount: forumPosts.likeCount,
        replyCount: forumPosts.replyCount,
        createdAt: forumPosts.createdAt,
        updatedAt: forumPosts.updatedAt,
        user: users,
      })
      .from(forumPosts)
      .leftJoin(users, eq(forumPosts.userId, users.id))
      .where(eq(forumPosts.id, id));

    if (!post) return undefined;

    const replies = await db
      .select({
        id: forumReplies.id,
        postId: forumReplies.postId,
        userId: forumReplies.userId,
        content: forumReplies.content,
        likeCount: forumReplies.likeCount,
        createdAt: forumReplies.createdAt,
        user: users,
      })
      .from(forumReplies)
      .leftJoin(users, eq(forumReplies.userId, users.id))
      .where(eq(forumReplies.postId, id))
      .orderBy(forumReplies.createdAt);

    // Increment view count
    await db
      .update(forumPosts)
      .set({ viewCount: sql`${forumPosts.viewCount} + 1` })
      .where(eq(forumPosts.id, id));

    return { ...post, replies };
  }

  async createForumPost(post: InsertForumPost): Promise<ForumPost> {
    const [newPost] = await db.insert(forumPosts).values(post).returning();
    return newPost;
  }

  async createForumReply(reply: InsertForumReply): Promise<ForumReply> {
    const [newReply] = await db.insert(forumReplies).values(reply).returning();
    
    // Update post reply count
    await db
      .update(forumPosts)
      .set({ 
        replyCount: sql`${forumPosts.replyCount} + 1`,
        updatedAt: new Date()
      })
      .where(eq(forumPosts.id, reply.postId!));

    return newReply;
  }

  async likeForumPost(userId: string, postId: number): Promise<void> {
    // Check if already liked
    const [existing] = await db
      .select()
      .from(forumLikes)
      .where(and(eq(forumLikes.userId, userId), eq(forumLikes.postId, postId)));

    if (!existing) {
      await db.insert(forumLikes).values({ userId, postId });
      await db
        .update(forumPosts)
        .set({ likeCount: sql`${forumPosts.likeCount} + 1` })
        .where(eq(forumPosts.id, postId));
    }
  }

  async unlikeForumPost(userId: string, postId: number): Promise<void> {
    const deleted = await db
      .delete(forumLikes)
      .where(and(eq(forumLikes.userId, userId), eq(forumLikes.postId, postId)))
      .returning();

    if (deleted.length > 0) {
      await db
        .update(forumPosts)
        .set({ likeCount: sql`${forumPosts.likeCount} - 1` })
        .where(eq(forumPosts.id, postId));
    }
  }

  // Analytics
  async getDashboardStats(userId: string): Promise<{
    todayAppointments: number;
    weekRevenue: number;
    monthRevenue: number;
    totalClients: number;
  }> {
    const today = new Date().toISOString().split('T')[0];
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const [todayAppointments] = await db
      .select({ count: count() })
      .from(appointments)
      .where(and(
        eq(appointments.userId, userId),
        eq(appointments.appointmentDate, today)
      ));

    const [weekRevenue] = await db
      .select({ sum: sql<string>`COALESCE(SUM(${appointments.totalPrice}), 0)` })
      .from(appointments)
      .where(and(
        eq(appointments.userId, userId),
        gte(appointments.appointmentDate, weekAgo),
        eq(appointments.status, 'completed')
      ));

    const [monthRevenue] = await db
      .select({ sum: sql<string>`COALESCE(SUM(${appointments.totalPrice}), 0)` })
      .from(appointments)
      .where(and(
        eq(appointments.userId, userId),
        gte(appointments.appointmentDate, monthAgo),
        eq(appointments.status, 'completed')
      ));

    const [totalClients] = await db
      .select({ count: count() })
      .from(clients)
      .where(eq(clients.userId, userId));

    return {
      todayAppointments: todayAppointments?.count || 0,
      weekRevenue: parseFloat(weekRevenue?.sum || '0'),
      monthRevenue: parseFloat(monthRevenue?.sum || '0'),
      totalClients: totalClients?.count || 0,
    };
  }

  // Advanced Analytics for Dashboard
  async getRevenueChart(userId: string): Promise<Array<{ date: string; revenue: number }>> {
    // Generate realistic demo data for last 30 days
    const data = [];
    const today = new Date();
    
    for (let i = 29; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      // Generate realistic revenue based on day of week
      const dayOfWeek = date.getDay();
      let baseRevenue = 0;
      
      if (dayOfWeek === 0) { // Sunday - closed
        baseRevenue = 0;
      } else if (dayOfWeek === 6) { // Saturday - busy
        baseRevenue = 800 + Math.random() * 400;
      } else if (dayOfWeek >= 1 && dayOfWeek <= 5) { // Weekdays
        baseRevenue = 400 + Math.random() * 300;
      }
      
      data.push({
        date: dateStr,
        revenue: Math.round(baseRevenue)
      });
    }
    
    return data;
  }

  async getUpcomingAppointments(userId: string): Promise<Array<{ date: string; time: string; clientName: string; serviceName: string }>> {
    // Generate demo upcoming appointments
    const appointments = [];
    const today = new Date();
    
    const clients = ['Sophie Martin', 'Emma Leroy', 'Marie Dubois', 'Claire Bernard', 'Julie Moreau'];
    const services = ['Coupe + Brushing', 'Coloration', 'Mèches', 'Soin Hydratant', 'Balayage'];
    const times = ['09:00', '10:30', '14:00', '15:30', '16:30'];
    
    for (let i = 0; i < 6; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() + Math.floor(i / 2));
      
      appointments.push({
        date: date.toISOString().split('T')[0],
        time: times[i % times.length],
        clientName: clients[i % clients.length],
        serviceName: services[i % services.length]
      });
    }
    
    return appointments;
  }

  async getTopServices(userId: string): Promise<Array<{ serviceName: string; count: number; revenue: number }>> {
    // Demo data for top services
    return [
      { serviceName: 'Coupe + Brushing', count: 45, revenue: 2250 },
      { serviceName: 'Coloration', count: 28, revenue: 3360 },
      { serviceName: 'Balayage', count: 22, revenue: 3300 },
      { serviceName: 'Mèches', count: 18, revenue: 2160 },
      { serviceName: 'Soin Hydratant', count: 15, revenue: 750 }
    ];
  }

  async getStaffPerformance(userId: string): Promise<Array<{ staffName: string; revenue: number; appointmentCount: number }>> {
    // Demo staff performance data
    return [
      { staffName: 'Marie Dubois', revenue: 4850, appointmentCount: 68 },
      { staffName: 'Sophie Martin', revenue: 3720, appointmentCount: 52 },
      { staffName: 'Emma Leroy', revenue: 2890, appointmentCount: 41 }
    ];
  }

  // Reviews operations
  async getReviews(userId: string): Promise<(Review & { client: Client; service: Service })[]> {
    return await db
      .select()
      .from(reviews)
      .leftJoin(clients, eq(reviews.clientId, clients.id))
      .leftJoin(services, eq(reviews.serviceId, services.id))
      .where(eq(reviews.userId, userId))
      .orderBy(desc(reviews.createdAt));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    return newReview;
  }

  // Advanced Analytics operations
  async getAnalyticsOverview(userId: string, timeRange: string): Promise<any> {
    const daysBack = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : timeRange === '90d' ? 90 : 365;
    
    return {
      totalRevenue: '12,450',
      revenueGrowth: '15',
      newClients: 28,
      clientGrowth: '12',
      retentionRate: 87,
      averageRating: 4.8,
      totalReviews: 156
    };
  }

  async getAnalyticsRevenueChart(userId: string, timeRange: string): Promise<any[]> {
    const daysBack = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : timeRange === '90d' ? 90 : 365;
    const data = [];
    const today = new Date();
    
    for (let i = daysBack - 1; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      
      const dayOfWeek = date.getDay();
      let baseRevenue = 0;
      
      if (dayOfWeek === 0) {
        baseRevenue = 0;
      } else if (dayOfWeek === 6) {
        baseRevenue = 800 + Math.random() * 400;
      } else {
        baseRevenue = 400 + Math.random() * 300;
      }
      
      data.push({
        date: date.toLocaleDateString('fr-FR', { month: 'short', day: 'numeric' }),
        revenue: Math.round(baseRevenue)
      });
    }
    
    return data;
  }

  async getClientSegments(userId: string, timeRange: string): Promise<any[]> {
    return [
      { name: 'Nouveaux', value: 35 },
      { name: 'Réguliers', value: 45 },
      { name: 'VIP', value: 15 },
      { name: 'Inactifs', value: 5 }
    ];
  }

  async getServiceAnalytics(userId: string, timeRange: string): Promise<any[]> {
    return [
      { name: 'Coupe', revenue: 3200, appointments: 64 },
      { name: 'Coloration', revenue: 4800, appointments: 32 },
      { name: 'Balayage', revenue: 3600, appointments: 24 },
      { name: 'Soins', revenue: 1200, appointments: 48 },
      { name: 'Mèches', revenue: 2400, appointments: 20 }
    ];
  }

  async getLoyaltyStats(userId: string): Promise<any> {
    return {
      totalMembers: 267,
      pointsRedeemed: 15420,
      avgLoyaltyScore: 78
    };
  }

  async getTopClients(userId: string, timeRange: string): Promise<any[]> {
    return [
      {
        id: 1,
        firstName: 'Sophie',
        lastName: 'Martin',
        totalSpent: 1250,
        visitCount: 12,
        lastVisit: new Date().toISOString(),
        loyaltyLevel: 'gold'
      },
      {
        id: 2,
        firstName: 'Emma',
        lastName: 'Leroy',
        totalSpent: 890,
        visitCount: 8,
        lastVisit: new Date().toISOString(),
        loyaltyLevel: 'silver'
      },
      {
        id: 3,
        firstName: 'Marie',
        lastName: 'Dubois',
        totalSpent: 2150,
        visitCount: 18,
        lastVisit: new Date().toISOString(),
        loyaltyLevel: 'platinum'
      }
    ];
  }

  // Loyalty program operations
  async getLoyaltyProgram(clientId: number): Promise<LoyaltyProgram | undefined> {
    const [loyalty] = await db
      .select()
      .from(loyaltyProgram)
      .where(eq(loyaltyProgram.clientId, clientId));
    return loyalty;
  }

  async createLoyaltyProgram(loyalty: InsertLoyaltyProgram): Promise<LoyaltyProgram> {
    const [newLoyalty] = await db.insert(loyaltyProgram).values(loyalty).returning();
    return newLoyalty;
  }

  async updateLoyaltyPoints(clientId: number, points: number): Promise<void> {
    await db
      .update(loyaltyProgram)
      .set({ 
        points: sql`${loyaltyProgram.points} + ${points}`,
        lastActivity: new Date()
      })
      .where(eq(loyaltyProgram.clientId, clientId));
  }
}

export const storage = new DatabaseStorage();
