type Item = { label: string; href: string };
type Props = { items: Item[]; floating?: boolean };

export function BottomNavigation({ items, floating = false }: Props) {
  return (
    <nav
      style={{
        position: floating ? 'fixed' : 'static',
        bottom: floating ? 16 : undefined,
        left: floating ? 0 : undefined,
        right: floating ? 0 : undefined,
        margin: '0 auto',
        maxWidth: 640,
        borderRadius: 12,
        boxShadow: floating ? '0 8px 24px rgba(0,0,0,.15)' : undefined,
        background: '#fff',
        padding: 12,
        display: 'flex',
        gap: 12,
        justifyContent: 'space-around',
      }}
    >
      {items.map((it) => (
        <a key={it.href} href={it.href}>
          {it.label}
        </a>
      ))}
    </nav>
  );
}
