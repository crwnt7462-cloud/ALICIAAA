import { useEffect, useState } from 'react';

export default function App() {
  const [health, setHealth] = useState<string>('…');
  useEffect(() => {
    fetch(`${import.meta.env.VITE_API_URL}/health`)
      .then((r) => r.json())
      .then(() => setHealth('OK'))
      .catch(() => setHealth('KO'));
  }, []);

  return (
    <div style={{ padding: 24 }}>
      <h1>Salon • Dashboard</h1>
      <p>API health: {health}</p>
    </div>
  );
}
