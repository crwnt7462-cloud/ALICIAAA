#!/usr/bin/env bash
set -euo pipefail

# 0) Sauvegarde
git add -A && git commit -m "chore: checkpoint avant nettoyage" || true

# 1) Purge des artefacts/archives
git rm -r -f --cached --ignore-unmatch Archive_2/tmp || true
git rm -r -f --cached --ignore-unmatch __MACOSX || true
git rm -f --cached --ignore-unmatch "Archive_3/salon-beaute-code-complet.zip" || true

# 2) Front — supprimer les doublons
git rm -f --cached --ignore-unmatch client/src/App.optimized.tsx || true
git rm -f --cached --ignore-unmatch client/src/components/BottomNavigationFloating.tsx || true

# 3) Back — unifier les routes
if [ -f server/routes.ts ]; then
  git mv server/routes.ts server/routes/_legacy.ts || true
fi

# 4) Choisir UNE stack (décommente le bloc voulu puis exécute)

## Option A: garder Supabase/Neon/Drizzle → purger Firebase/Replit Auth
# git rm -f --cached --ignore-unmatch server/firebaseAdmin.ts server/firebaseSetup.ts server/replitAuth.ts || true

## Option B: garder Firebase → purger Supabase/Neon/Drizzle
# git rm -f --cached --ignore-unmatch server/supabaseSetup.ts server/db.ts server/drizzle*.ts server/neon*.ts || true

echo "Nettoyage terminé. Pense à passer ESLint/TS et à rebrancher les routes."
