import type { NextFunction, Request, Response } from 'express';
import type { Logger } from 'pino';

export const errorHandler = (logger: Logger) => (err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = err.status && Number.isInteger(err.status) ? err.status : 500;
  logger.error({ err }, 'unhandled_error');
  res.status(status).json({ error: { message: err.message ?? 'Internal Error' } });
};
