import express from 'express';
import cors from 'cors';
import pino from 'pino';
import { z } from 'zod';
import { errorHandler } from './middlewares/errorHandler';
import { routerV1 } from './routes/v1';

const app = express();
const logger = pino();

app.use(cors());
app.use(express.json());

// Health
app.get('/health', (_req, res) => res.json({ ok: true }));

// API v1
app.use('/api/v1', routerV1);

// 404 (API)
app.use((_req, _res, next) => {
  const err = new Error('Not Found');
  // @ts-ignore
  err.status = 404;
  next(err);
});

app.use(errorHandler(logger));

const port = process.env.PORT ? Number(process.env.PORT) : 3000;
app.listen(port, () => logger.info({ port }, 'server started'));
