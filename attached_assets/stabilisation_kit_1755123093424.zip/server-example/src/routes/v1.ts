import { Router } from 'express';
import { z } from 'zod';

export const routerV1 = Router();

const createBookingSchema = z.object({
  userId: z.string().min(1),
  date: z.string().datetime(),
  serviceId: z.string().min(1),
});

routerV1.post('/bookings', (req, res, next) => {
  const parsed = createBookingSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  // TODO: call service layer, persist, etc.
  res.status(201).json({ booking: parsed.data });
});

routerV1.get('/bookings/:id', (req, res) => {
  // TODO: fetch by id
  res.json({ id: req.params.id });
});
